# Clés Stripe (à remplacer par vos vraies clés)
STRIPE_PUBLIC_KEY = 'votre_cle_publique'
STRIPE_SECRET_KEY = 'votre_cle_secrete'
